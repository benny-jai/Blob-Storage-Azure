﻿using DataContext.Models;


namespace DataContext.Abstractions
{
    public interface IProductRepository : IRepository<Product>
    {         
            
    }
}
